// 더미 데이터
const contacts = [
    {
        id: 1,
        name: "김민준",
        lastMessage: "다음 주 회의 일정 확인 부탁드립니다.",
        lastActive: "오늘 09:30",
        messages: []
    },
    {
        id: 2,
        name: "이서연",
        lastMessage: "프로젝트 제안서 검토 완료했습니다.",
        lastActive: "오늘 11:15",
        messages: []
    },
    {
        id: 3,
        name: "박지훈",
        lastMessage: "거래처 미팅 장소가 변경되었습니다.",
        lastActive: "어제 18:45",
        messages: []
    },
    {
        id: 4,
        name: "최수아",
        lastMessage: "견적서 수정본 보내드립니다.",
        lastActive: "2일 전",
        messages: []
    },
    {
        id: 5,
        name: "정도윤",
        lastMessage: "계약서 검토 의견 주셔서 감사합니다.",
        lastActive: "3일 전",
        messages: []
    }
];

// 메시지 더미 데이터
const messageData = {
    1: [ // 김민준
        {
            platform: "slack",
            content: "안녕하세요, 다음 주 화요일 오전 10시에 회의 일정 잡았습니다.",
            timestamp: "2023-05-26 09:15",
            date: "2023-05-26"
        },
        {
            platform: "email",
            content: "회의 안건 및 참석자 명단 첨부합니다. 검토 후 의견 주시면 감사하겠습니다.",
            timestamp: "2023-05-26 10:30",
            date: "2023-05-26"
        },
        {
            platform: "phone",
            content: "회의실 예약 관련해서 문의드립니다. 10명 수용 가능한 회의실로 예약 가능할까요?",
            timestamp: "2023-05-26 14:20",
            date: "2023-05-26"
        },
        {
            platform: "slack",
            content: "회의 자료 준비 상황 공유드립니다. PPT 초안 작성 중입니다.",
            timestamp: "2023-05-27 11:05",
            date: "2023-05-27"
        },
        {
            platform: "kakao",
            content: "혹시 오늘 저녁에 시간 되시면 간단히 회의 내용 사전 논의할 수 있을까요?",
            timestamp: "2023-05-27 15:40",
            date: "2023-05-27"
        },
        {
            platform: "email",
            content: "회의 참석자 명단이 변경되어 업데이트된 내용 전달드립니다.",
            timestamp: "2023-05-27 16:25",
            date: "2023-05-27"
        },
        {
            platform: "sms",
            content: "내일 회의 시간 10시에서 11시로 변경되었습니다. 확인 부탁드립니다.",
            timestamp: "2023-05-27 18:30",
            date: "2023-05-27"
        },
        {
            platform: "slack",
            content: "회의 자료 최종본 공유드립니다. 검토 부탁드립니다.",
            timestamp: "2023-05-27 20:15",
            date: "2023-05-27"
        },
        {
            platform: "phone",
            content: "내일 회의 전 간단한 사전 미팅 가능하실까요? 9시 30분에 잠깐 뵙고 싶습니다.",
            timestamp: "2023-05-27 21:00",
            date: "2023-05-27"
        },
        {
            platform: "slack",
            content: "다음 주 회의 일정 확인 부탁드립니다.",
            timestamp: "2023-05-27 22:30",
            date: "2023-05-27"
        }
    ],
    2: [ // 이서연
        {
            platform: "email",
            content: "안녕하세요, 프로젝트 제안서 초안 보내드립니다. 검토 부탁드립니다.",
            timestamp: "2023-05-25 08:45",
            date: "2023-05-25"
        },
        {
            platform: "slack",
            content: "제안서 3페이지 예산 부분에 수정이 필요할 것 같습니다. 의견 주시겠어요?",
            timestamp: "2023-05-25 10:20",
            date: "2023-05-25"
        },
        {
            platform: "phone",
            content: "예산 항목 세부 내역 논의를 위해 전화드렸습니다. 인건비 산정 방식에 대해 조언 부탁드립니다.",
            timestamp: "2023-05-25 13:10",
            date: "2023-05-25"
        },
        {
            platform: "kakao",
            content: "수정된 예산안 작성 중입니다. 오늘 오후에 공유드릴게요.",
            timestamp: "2023-05-25 15:30",
            date: "2023-05-25"
        },
        {
            platform: "email",
            content: "수정된 예산안 첨부합니다. 인건비와 운영비 항목 조정했습니다.",
            timestamp: "2023-05-25 17:45",
            date: "2023-05-25"
        },
        {
            platform: "slack",
            content: "내일 오전에 제안서 관련 피드백 회의 가능하실까요?",
            timestamp: "2023-05-25 18:20",
            date: "2023-05-25"
        },
        {
            platform: "sms",
            content: "내일 회의 10시에 진행하겠습니다. 회의실 예약 완료했습니다.",
            timestamp: "2023-05-25 19:05",
            date: "2023-05-25"
        },
        {
            platform: "email",
            content: "회의 안건 및 참석자 명단 공유드립니다.",
            timestamp: "2023-05-26 08:30",
            date: "2023-05-26"
        },
        {
            platform: "phone",
            content: "회의 결과를 반영한 최종 제안서 작성 중입니다. 오늘 오후까지 완료하겠습니다.",
            timestamp: "2023-05-26 14:15",
            date: "2023-05-26"
        },
        {
            platform: "slack",
            content: "프로젝트 제안서 검토 완료했습니다.",
            timestamp: "2023-05-27 11:15",
            date: "2023-05-27"
        }
    ],
    3: [ // 박지훈
        {
            platform: "kakao",
            content: "안녕하세요, 다음 주 거래처 미팅 일정 확정되었습니다. 화요일 오후 2시입니다.",
            timestamp: "2023-05-24 09:30",
            date: "2023-05-24"
        },
        {
            platform: "email",
            content: "미팅 안건 및 준비 자료 목록 공유드립니다. 필요한 자료 준비 부탁드립니다.",
            timestamp: "2023-05-24 11:20",
            date: "2023-05-24"
        },
        {
            platform: "slack",
            content: "제품 소개 자료는 제가 준비하고, 가격표는 팀장님이 준비해주시면 될 것 같습니다.",
            timestamp: "2023-05-24 13:45",
            date: "2023-05-24"
        },
        {
            platform: "phone",
            content: "거래처에서 요청한 추가 자료 목록 전달드립니다. 기술 명세서와 납품 일정 계획서입니다.",
            timestamp: "2023-05-24 16:10",
            date: "2023-05-24"
        },
        {
            platform: "email",
            content: "기술 명세서 초안 작성했습니다. 검토 부탁드립니다.",
            timestamp: "2023-05-25 10:05",
            date: "2023-05-25"
        },
        {
            platform: "slack",
            content: "납품 일정 계획서는 생산팀과 협의 후 오늘 오후에 작성하겠습니다.",
            timestamp: "2023-05-25 11:30",
            date: "2023-05-25"
        },
        {
            platform: "kakao",
            content: "생산팀과 미팅 완료했습니다. 납품 일정 계획서 작성 중입니다.",
            timestamp: "2023-05-25 15:20",
            date: "2023-05-25"
        },
        {
            platform: "email",
            content: "납품 일정 계획서 첨부합니다. 검토 후 의견 주시면 감사하겠습니다.",
            timestamp: "2023-05-25 17:40",
            date: "2023-05-25"
        },
        {
            platform: "sms",
            content: "내일 오전 10시에 미팅 자료 최종 점검하겠습니다. 회의실 예약했습니다.",
            timestamp: "2023-05-25 19:15",
            date: "2023-05-25"
        },
        {
            platform: "slack",
            content: "거래처 미팅 장소가 변경되었습니다.",
            timestamp: "2023-05-26 18:45",
            date: "2023-05-26"
        }
    ],
    4: [ // 최수아
        {
            platform: "email",
            content: "안녕하세요, 요청하신 제품 견적서 첨부합니다. 검토 부탁드립니다.",
            timestamp: "2023-05-23 10:15",
            date: "2023-05-23"
        },
        {
            platform: "phone",
            content: "견적서 관련해서 몇 가지 문의사항이 있으신 것 같아 전화드렸습니다. 수량 할인에 대해 논의하고 싶으시다고요?",
            timestamp: "2023-05-23 13:40",
            date: "2023-05-23"
        },
        {
            platform: "slack",
            content: "수량 할인 정책 내부 검토 중입니다. 오늘 오후에 결과 알려드리겠습니다.",
            timestamp: "2023-05-23 14:25",
            date: "2023-05-23"
        },
        {
            platform: "kakao",
            content: "영업팀과 협의 완료했습니다. 100개 이상 주문 시 10% 할인 가능합니다.",
            timestamp: "2023-05-23 16:50",
            date: "2023-05-23"
        },
        {
            platform: "email",
            content: "할인 정책이 반영된 수정 견적서 첨부합니다.",
            timestamp: "2023-05-23 17:30",
            date: "2023-05-23"
        },
        {
            platform: "phone",
            content: "배송 일정 관련해서 문의주셔서 전화드렸습니다. 주문 확정 후 2주 내 배송 가능합니다.",
            timestamp: "2023-05-24 11:10",
            date: "2023-05-24"
        },
        {
            platform: "slack",
            content: "특급 배송 요청 관련해서 물류팀과 협의 중입니다. 추가 비용 발생할 수 있습니다.",
            timestamp: "2023-05-24 14:35",
            date: "2023-05-24"
        },
        {
            platform: "email",
            content: "특급 배송 옵션이 포함된 최종 견적서 첨부합니다. 주문 확정 후 1주일 내 배송 가능합니다.",
            timestamp: "2023-05-24 16:20",
            date: "2023-05-24"
        },
        {
            platform: "sms",
            content: "견적서 관련 추가 문의사항 있으시면 언제든지 연락주세요.",
            timestamp: "2023-05-24 18:05",
            date: "2023-05-24"
        },
        {
            platform: "email",
            content: "견적서 수정본 보내드립니다.",
            timestamp: "2023-05-25 09:30",
            date: "2023-05-25"
        }
    ],
    5: [ // 정도윤
        {
            platform: "email",
            content: "안녕하세요, 계약서 초안 검토 부탁드립니다. 특히 납품 조건과 지불 조건 부분 확인 부탁드립니다.",
            timestamp: "2023-05-22 09:45",
            date: "2023-05-22"
        },
        {
            platform: "slack",
            content: "계약서 검토 중입니다. 납품 조건에서 몇 가지 수정이 필요해 보입니다.",
            timestamp: "2023-05-22 11:30",
            date: "2023-05-22"
        },
        {
            platform: "phone",
            content: "계약서 5조 납품 지연에 대한 페널티 조항이 너무 과도한 것 같습니다. 협의 가능할까요?",
            timestamp: "2023-05-22 14:15",
            date: "2023-05-22"
        },
        {
            platform: "email",
            content: "수정 의견 반영한 계약서 버전 첨부합니다. 변경사항은 빨간색으로 표시했습니다.",
            timestamp: "2023-05-22 16:40",
            date: "2023-05-22"
        },
        {
            platform: "kakao",
            content: "내일 오전에 계약 조건 최종 협의를 위한 미팅 가능하실까요?",
            timestamp: "2023-05-22 18:20",
            date: "2023-05-22"
        },
        {
            platform: "sms",
            content: "내일 미팅 10시에 진행하겠습니다. 회의실 예약 완료했습니다.",
            timestamp: "2023-05-22 19:05",
            date: "2023-05-22"
        },
        {
            platform: "slack",
            content: "미팅 준비 자료 공유드립니다. 쟁점 사항 정리했습니다.",
            timestamp: "2023-05-23 08:30",
            date: "2023-05-23"
        },
        {
            platform: "phone",
            content: "미팅 결과를 반영한 최종 계약서 작성 중입니다. 오늘 오후까지 공유드리겠습니다.",
            timestamp: "2023-05-23 13:10",
            date: "2023-05-23"
        },
        {
            platform: "email",
            content: "최종 계약서 첨부합니다. 검토 후 서명 부탁드립니다.",
            timestamp: "2023-05-23 16:45",
            date: "2023-05-23"
        },
        {
            platform: "slack",
            content: "계약서 검토 의견 주셔서 감사합니다.",
            timestamp: "2023-05-24 10:20",
            date: "2023-05-24"
        }
    ]
};

// AI 요약 더미 데이터
const summaryData = {
    1: {
        keywords: [
            { text: "회의", color: "tag-blue" },
            { text: "일정", color: "tag-green" },
            { text: "자료", color: "tag-purple" },
            { text: "참석자", color: "tag-orange" },
            { text: "PPT", color: "tag-red" }
        ],
        todos: [
            { text: "회의 자료 검토하기", checked: false },
            { text: "참석자 명단 확인하기", checked: true },
            { text: "회의실 예약 확인하기", checked: true },
            { text: "사전 미팅 9시 30분", checked: false }
        ],
        nextContact: "2023-05-28"
    },
    2: {
        keywords: [
            { text: "제안서", color: "tag-blue" },
            { text: "예산", color: "tag-green" },
            { text: "검토", color: "tag-purple" },
            { text: "회의", color: "tag-orange" },
            { text: "피드백", color: "tag-teal" }
        ],
        todos: [
            { text: "제안서 최종 검토", checked: true },
            { text: "예산안 승인 요청", checked: false },
            { text: "회의 결과 정리", checked: true },
            { text: "최종 제출 일정 확인", checked: false }
        ],
        nextContact: "2023-05-29"
    },
    3: {
        keywords: [
            { text: "미팅", color: "tag-blue" },
            { text: "거래처", color: "tag-green" },
            { text: "자료", color: "tag-purple" },
            { text: "납품", color: "tag-orange" },
            { text: "일정", color: "tag-red" }
        ],
        todos: [
            { text: "미팅 자료 준비", checked: true },
            { text: "기술 명세서 검토", checked: true },
            { text: "납품 일정 계획 확인", checked: true },
            { text: "변경된 미팅 장소 확인", checked: false }
        ],
        nextContact: "2023-05-30"
    },
    4: {
        keywords: [
            { text: "견적서", color: "tag-blue" },
            { text: "할인", color: "tag-green" },
            { text: "배송", color: "tag-purple" },
            { text: "주문", color: "tag-orange" },
            { text: "수량", color: "tag-teal" }
        ],
        todos: [
            { text: "수정 견적서 발송", checked: true },
            { text: "할인 정책 확인", checked: true },
            { text: "특급 배송 옵션 안내", checked: true },
            { text: "주문 확정 여부 확인", checked: false }
        ],
        nextContact: "2023-05-31"
    },
    5: {
        keywords: [
            { text: "계약서", color: "tag-blue" },
            { text: "검토", color: "tag-green" },
            { text: "납품", color: "tag-purple" },
            { text: "조건", color: "tag-orange" },
            { text: "미팅", color: "tag-red" }
        ],
        todos: [
            { text: "계약서 최종 검토", checked: true },
            { text: "서명 요청", checked: true },
            { text: "납품 조건 확인", checked: true },
            { text: "계약 체결 후 일정 조율", checked: false }
        ],
        nextContact: "2023-06-01"
    }
};

// 현재 선택된 연락처 ID
let selectedContactId = null;

// 페이지 로드 시 실행
document.addEventListener('DOMContentLoaded', function() {
    // 연락처 목록 렌더링
    renderContactList();
    
    // 검색 기능 이벤트 리스너
    document.getElementById('contact-search').addEventListener('input', function() {
        filterContacts(this.value);
    });
    
    // 메시지 전송 버튼 이벤트 리스너
    document.getElementById('send-message-btn').addEventListener('click', sendNewMessage);
    
    // 메시지 입력 필드 엔터키 이벤트 리스너
    document.getElementById('message-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendNewMessage();
        }
    });
    
    // 요약 업데이트 버튼 이벤트 리스너
    document.getElementById('update-summary-btn').addEventListener('click', updateSummary);
});

// 연락처 목록 렌더링 함수
function renderContactList() {
    const contactListElement = document.getElementById('contact-list');
    contactListElement.innerHTML = '';
    
    contacts.forEach(contact => {
        const contactCard = document.createElement('div');
        contactCard.className = 'contact-card';
        contactCard.dataset.id = contact.id;
        
        contactCard.innerHTML = `
            <div class="contact-name">${contact.name}</div>
            <div class="contact-preview">${contact.lastMessage}</div>
            <div class="contact-time">${contact.lastActive}</div>
        `;
        
        contactCard.addEventListener('click', function() {
            selectContact(contact.id);
        });
        
        contactListElement.appendChild(contactCard);
    });
}

// 연락처 검색 필터링 함수
function filterContacts(searchTerm) {
    const contactCards = document.querySelectorAll('.contact-card');
    const searchTermLower = searchTerm.toLowerCase();
    
    contactCards.forEach(card => {
        const contactName = card.querySelector('.contact-name').textContent.toLowerCase();
        if (contactName.includes(searchTermLower)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

// 연락처 선택 함수
function selectContact(contactId) {
    selectedContactId = contactId;
    
    // 활성화된 연락처 카드 스타일 변경
    document.querySelectorAll('.contact-card').forEach(card => {
        if (parseInt(card.dataset.id) === contactId) {
            card.classList.add('active');
        } else {
            card.classList.remove('active');
        }
    });
    
    // 선택된 연락처 이름 표시
    const selectedContact = contacts.find(contact => contact.id === contactId);
    document.getElementById('selected-contact-name').textContent = selectedContact.name;
    
    // 대화 내용 로드
    loadConversation(contactId);
    
    // AI 요약 로드
    loadSummary(contactId);
}

// 대화 내용 로드 함수
function loadConversation(contactId) {
    const conversationElement = document.getElementById('conversation-timeline');
    conversationElement.innerHTML = '';
    
    if (!messageData[contactId] || messageData[contactId].length === 0) {
        conversationElement.innerHTML = `
            <div class="empty-state">
                <p>대화 내용이 없습니다</p>
            </div>
        `;
        return;
    }
    
    // 날짜별로 메시지 그룹화
    const messagesByDate = {};
    messageData[contactId].forEach(message => {
        if (!messagesByDate[message.date]) {
            messagesByDate[message.date] = [];
        }
        messagesByDate[message.date].push(message);
    });
    
    // 날짜별로 정렬하여 표시
    Object.keys(messagesByDate).sort().forEach(date => {
        const messageGroup = document.createElement('div');
        messageGroup.className = 'message-group';
        
        // 날짜 표시
        const dateHeader = document.createElement('div');
        dateHeader.className = 'message-date';
        dateHeader.innerHTML = `<span>${formatDate(date)}</span>`;
        messageGroup.appendChild(dateHeader);
        
        // 해당 날짜의 메시지들 표시
        messagesByDate[date].forEach(message => {
            const messageElement = document.createElement('div');
            messageElement.className = `message-bubble message-${message.platform}`;
            
            // 플랫폼 아이콘 및 이름
            let platformIconSrc = '';
            let platformName = '';
            
            switch (message.platform) {
                case 'slack':
                    platformIconSrc = 'images/slack.svg';
                    platformName = 'Slack';
                    break;
                case 'phone':
                    platformIconSrc = 'images/phone.svg';
                    platformName = '전화';
                    break;
                case 'email':
                    platformIconSrc = 'images/email.svg';
                    platformName = '이메일';
                    break;
                case 'sms':
                    platformIconSrc = 'images/sms.svg';
                    platformName = 'SMS';
                    break;
                case 'kakao':
                    platformIconSrc = 'images/kakao.svg';
                    platformName = '카카오톡';
                    break;
            }
            
            messageElement.innerHTML = `
                <div class="message-platform"><img src="${platformIconSrc}" alt="${platformName}" width="16" height="16"> ${platformName}</div>
                <div class="message-content">${message.content}</div>
                <div class="message-time">${formatTime(message.timestamp)}</div>
            `;
            
            messageGroup.appendChild(messageElement);
        });
        
        conversationElement.appendChild(messageGroup);
    });
    
    // 스크롤을 가장 아래로 이동
    conversationElement.scrollTop = conversationElement.scrollHeight;
}

// AI 요약 로드 함수
function loadSummary(contactId) {
    const summaryElement = document.getElementById('summary-content');
    
    if (!summaryData[contactId]) {
        summaryElement.innerHTML = `
            <div class="empty-state">
                <p>요약 정보가 없습니다</p>
            </div>
        `;
        return;
    }
    
    const summary = summaryData[contactId];
    
    let keywordsHTML = '';
    summary.keywords.forEach(keyword => {
        keywordsHTML += `<span class="keyword-tag ${keyword.color}">${keyword.text}</span>`;
    });
    
    let todosHTML = '';
    summary.todos.forEach(todo => {
        todosHTML += `
            <li class="todo-item">
                <input type="checkbox" class="todo-checkbox" ${todo.checked ? 'checked' : ''}>
                <span>${todo.text}</span>
            </li>
        `;
    });
    
    summaryElement.innerHTML = `
        <div class="summary-section">
            <h3>주요 키워드</h3>
            <div class="keyword-tags">
                ${keywordsHTML}
            </div>
        </div>
        
        <div class="summary-section">
            <h3>약속된 할일 목록</h3>
            <ul class="todo-list">
                ${todosHTML}
            </ul>
        </div>
        
        <div class="summary-section">
            <h3>다음 연락 추천일</h3>
            <div class="next-contact">
                <div>다음 연락 일정</div>
                <div class="next-contact-date">${formatDate(summary.nextContact)}</div>
            </div>
        </div>
    `;
    
    // 체크박스 이벤트 리스너 추가
    document.querySelectorAll('.todo-checkbox').forEach((checkbox, index) => {
        checkbox.addEventListener('change', function() {
            summaryData[selectedContactId].todos[index].checked = this.checked;
        });
    });
}

// 새 메시지 전송 함수
function sendNewMessage() {
    if (!selectedContactId) {
        alert('연락처를 먼저 선택해주세요.');
        return;
    }
    
    const messageInput = document.getElementById('message-input');
    const platformSelect = document.getElementById('platform-select');
    
    const messageContent = messageInput.value.trim();
    if (!messageContent) return;
    
    const platform = platformSelect.value;
    const now = new Date();
    const timestamp = formatDateTime(now);
    const date = formatDateForData(now);
    
    // 새 메시지 객체 생성
    const newMessage = {
        platform: platform,
        content: messageContent,
        timestamp: timestamp,
        date: date
    };
    
    // 메시지 데이터에 추가
    if (!messageData[selectedContactId]) {
        messageData[selectedContactId] = [];
    }
    messageData[selectedContactId].push(newMessage);
    
    // 선택된 연락처의 마지막 메시지 업데이트
    const contactIndex = contacts.findIndex(contact => contact.id === selectedContactId);
    if (contactIndex !== -1) {
        contacts[contactIndex].lastMessage = messageContent;
        contacts[contactIndex].lastActive = '방금 전';
    }
    
    // 연락처 목록 다시 렌더링
    renderContactList();
    
    // 대화 내용 다시 로드
    loadConversation(selectedContactId);
    
    // 입력 필드 초기화
    messageInput.value = '';
}

// AI 요약 업데이트 함수 (시뮬레이션)
function updateSummary() {
    if (!selectedContactId) {
        alert('연락처를 먼저 선택해주세요.');
        return;
    }
    
    // 로딩 표시
    const summaryElement = document.getElementById('summary-content');
    summaryElement.innerHTML = `
        <div class="empty-state">
            <p>AI가 대화 내용을 분석 중입니다...</p>
        </div>
    `;
    
    // 1초 후 업데이트된 요약 표시 (실제로는 API 호출 등이 필요)
    setTimeout(() => {
        // 기존 키워드에 새 키워드 추가 (시뮬레이션)
        if (summaryData[selectedContactId]) {
            // 랜덤하게 키워드 순서 변경 및 중요도 조정
            summaryData[selectedContactId].keywords.sort(() => Math.random() - 0.5);
            
            // 할일 목록 중 하나 완료 처리 (시뮬레이션)
            const uncompletedTodos = summaryData[selectedContactId].todos.filter(todo => !todo.checked);
            if (uncompletedTodos.length > 0) {
                const randomIndex = Math.floor(Math.random() * uncompletedTodos.length);
                const todoIndex = summaryData[selectedContactId].todos.findIndex(todo => 
                    todo.text === uncompletedTodos[randomIndex].text);
                if (todoIndex !== -1) {
                    summaryData[selectedContactId].todos[todoIndex].checked = true;
                }
            }
            
            // 다음 연락일 업데이트 (시뮬레이션)
            const nextDate = new Date(summaryData[selectedContactId].nextContact);
            nextDate.setDate(nextDate.getDate() + 1);
            summaryData[selectedContactId].nextContact = formatDateForData(nextDate);
        }
        
        // 요약 다시 로드
        loadSummary(selectedContactId);
    }, 1000);
}

// 날짜 포맷팅 함수 (표시용)
function formatDate(dateStr) {
    const date = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    
    if (date.toDateString() === today.toDateString()) {
        return '오늘';
    } else if (date.toDateString() === yesterday.toDateString()) {
        return '어제';
    } else {
        return `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일`;
    }
}

// 시간 포맷팅 함수
function formatTime(timestampStr) {
    const date = new Date(timestampStr);
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const ampm = hours >= 12 ? '오후' : '오전';
    const formattedHours = hours % 12 || 12;
    const formattedMinutes = minutes < 10 ? '0' + minutes : minutes;
    
    return `${ampm} ${formattedHours}:${formattedMinutes}`;
}

// 날짜 및 시간 포맷팅 함수 (데이터용)
function formatDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    
    return `${year}-${month}-${day} ${hours}:${minutes}`;
}

// 날짜 포맷팅 함수 (데이터용)
function formatDateForData(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
}
